public class EmptyException extends Exception {
}
